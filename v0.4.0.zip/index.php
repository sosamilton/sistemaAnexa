<?php

	header('Location: ./web/app.php');
