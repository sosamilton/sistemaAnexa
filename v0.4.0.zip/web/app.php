<?php
namespace Anexa\APP;
error_reporting(E_ALL); 
ini_set("display_errors", 1); 

include(__DIR__."/../app/Autoloader.php");

$route=(isset($_SERVER["PATH_INFO"]))?$_SERVER["PATH_INFO"]:"/inicio";
$frontController = new Kernel(substr($route, 1), $_REQUEST) ;
$frontController->run();