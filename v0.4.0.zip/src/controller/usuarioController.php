<?php
namespace Anexa\Controller;
use Doctrine\ORM\EntityManager;
use Doctrine\ORM\EntityRepository;
use Anexa\Model\Entity\Usuario;
use Anexa\APP\Kernel;
use \Exception;


class usuarioController {

    public function indexAction($parametros=null) {
        $usuarios = $GLOBALS['em']->getRepository("Anexa\Model\Entity\Usuario")->findByBorrado(false);
        $datos = array(
            'menu' => "usuario",
            'usuarios' => $usuarios,
        );
        if (!empty($parametros)) {
            $datos['msj'] = $parametros['msj'];
            $datos['success'] = $parametros['success'];
        }
        return $GLOBALS['twig']->render('backend/usuario/index.html.twig', $datos);
    }

    public function createAction($request) {
        if (!empty($request)){
            return $this->setAction($request, new Usuario, 'creado');
        }else{
            $roles = $GLOBALS['em']->getRepository('Anexa\Model\Entity\Rol')->findByBorrado(false);
            return $GLOBALS['twig']->render('backend/usuario/agregar.html.twig',array(
                'menu' => "usuario",
                'roles' => $roles
            ));
        }
    } 

    public function setAction($request, $usuario, $accion) {
        try {
            $usuario->setUsername($request["username"]);
            if ($accion == "editado") {
                if (!empty($request["pass"])) {
                    $usuario->setPassword($request["pass"]); 
                }
            }else{
                $usuario->setPassword($request["pass"]); 
            }
            $rol = $GLOBALS['em']->getRepository('Anexa\Model\Entity\Rol')->findOneById($request["rol"]);
            $usuario->setRol($rol);
            $GLOBALS['em']->persist($usuario);
            $GLOBALS['em']->flush();
            $msj = ' el usuario '.$request["username"].' fue '.$accion.' correctamente! :)';
            $success=true;         
        } catch (Exception $e) {
            $msj=" Hubo un error al cargar el usuario! :(";
            $success=false;         
        }
        $datos=array(
            'msj' => $msj,
            'success' => $success
        );
        return $this->indexAction($datos);
    }

    public function updateAction($request){
        if (isset($request['id'])) {
            $usuario = $GLOBALS['em']->getRepository('Anexa\Model\Entity\Usuario')->findOneById($request['id']);
            unset($request['id']);
        }else{
            $datos=array(
                'msj' => ' no puede editar un usuario sin pasar su identificacion!',
                'success' => 0
            );
            return $this->indexAction($datos);
        }
        if (!empty($request)){
            return $this->setAction($request, $usuario, 'editado');
        }else{
            $roles = $GLOBALS['em']->getRepository('Anexa\Model\Entity\Rol')->findAll();
            return $GLOBALS['twig']->render('backend/usuario/editar.html.twig',array(
                'menu' => "usuario",
                'usuario' => $usuario,
                'roles' => $roles,
            ));
        }
    }

    public function viewAction($request){
        if (isset($request['id'])) {
            $usuario = $GLOBALS['em']->getRepository('Anexa\Model\Entity\Usuario')->findOneById($request['id']);
            return $GLOBALS['twig']->render('backend/usuario/ver.html.twig',array(
                'menu' => "usuario",
                'usuario' => $usuario,
            ));
        }else{
            $datos=array(
                'msj' => ' no puede ver un alumno sin pasar su identificacion!',
                'success' => 0
            );
            return $this->indexAction($datos);
        }
    } 

    public function toogleAction($request){
        if (isset($request['id'])) {
            $usuario = $GLOBALS['em']->getRepository('Anexa\Model\Entity\Usuario')->findOneById($request['id']);
            $usuario->toogleHabilitado();
            $GLOBALS['em']->persist($usuario);
            $GLOBALS['em']->flush();
            if ($usuario->getHabilitado()) {
                $estado = 'habilitado';
            }else{
                $estado = 'deshabilitado';
            }
            $datos=array( 'msj' => 'El usuario '.$usuario->getUsername().'se ha '.$estado. ' correctamente! ', 'success' => 1);
            return $this->indexAction($datos);
        }else{
            $datos=array(
                'msj' => ' no puede ver un alumno sin pasar su identificacion!',
                'success' => 0
            );
            return $this->indexAction($datos);
        }
    }

    public function deleteAction($request){
        if (isset($request['id'])) {
            $usuario = $GLOBALS['em']->getRepository('Anexa\Model\Entity\Usuario')->findOneById($request['id']);
            $usuario->borrar();
            $GLOBALS['em']->persist($usuario);
            $GLOBALS['em']->flush();
            $datos=array( 'msj' => 'El usuario '.$usuario->getUsername().'se ha borrado correctamente! ', 'success' => 1);
            return $this->indexAction($datos);
        }else{
            $datos=array(
                'msj' => ' no puede ver un alumno sin pasar su identificacion!',
                'success' => 0
            );
            return $this->indexAction($datos);
        }
    } 

    public function logoutAction(){
        session_destroy();
        $ruta = new Kernel('inicio', $_REQUEST) ;
        return $ruta->run(); 
    }

	public function loginAction($params) {
        if (!empty($params)) {
            if (trim($params['user']) != "" && trim($params['pass']) != ""){
                $user = $GLOBALS['em']->getRepository("Anexa\Model\Entity\Usuario")->findOneByUsername($params['user']);
                if (isset($user) && $user->getHabilitado() && !$user->getBorrado()) {
                    
                    $pass=md5($params['pass']);

                    if ($pass == $user->getPassword()) {
                        if(!isset($_SESSION)){ 
                            session_start(); 
                        }else{
                            session_destroy();
                            session_start(); 
                        }
                        $_SESSION['username']=$user->getUsername();
                        $_SESSION['id']=$user->getId();
                        $_SESSION['rol']= $user->getRol()->getNombre();
                        $ruta = new Kernel('inicio', $_REQUEST) ;
                        return $ruta->run();
                    }
                }
            }
        }
        return $GLOBALS['twig']->render('frontend/login.html.twig',array(
            'error' => "Usuario o Contraseña Incorrectos"
        ));
    }


	/*public function createAction() {
            $params =array();   
            $GLOBALS['em'] = $this->getDoctrine()->getEntityManager();     
            if ( isset($_SESSION['ROL_ADMIN'])){
                $id = (int) $_SESSION['ROL_ADMIN'];                
                $usuario = $GLOBALS['em']->getRepository("model:Usuario")->find($id);                
                if ($usuario != NULL){
                    $params['usuario'] = $usuario;
                    $params['is_admin'] = True;
                }
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                	$validar=array(
                    array(trim($_POST['username']), 'string'),
                    array(trim($_POST['password']), 'string'),
                    array(trim($_POST['rol']), 'string')
                    );
                	/////////////////////////////////
                    if (Controller::paramsValidator($validar)){  
                            $usuario = new Usuario();
                            $usuario->setUsername($_POST['username']);
                            $usuario->setPassword($_POST['password']);
                            $usuario->setRolId((int)$_POST['rol']);
                            
                            // ??$usuario = $GLOBALS['em']->getRepository('model:Usuario');
		                    $GLOBALS['em']->persist($usuario);
		                    $GLOBALS['em']->flush();
                        } 
                        // falta llamado a la vista
                    }
                }
        }*/




}