<?php
namespace Anexa\Controller;
use Anexa\Model\Entity\Cuota;
use Anexa\Model\Entity\Pago;
use Anexa\Model\Entity\Alumno;
use Doctrine\Common\Collections\ArrayCollection;
use \Exception;



class pagoController {

  

	public function indexAction(){ //muestra los alumnos 
         
    $alumnos = $GLOBALS['em']->getRepository('Anexa\Model\Entity\Alumno')->findByBorrado(false); 
    if (count($alumnos == 0)){
      $datos = array ('msj' => ' No hay alumnos cargados en el sistema');
    } 
    	
    $datos = array(
      'alumnos' => $alumnos,
      'menu' => 'pago',
    );  
       	  
    return $GLOBALS['twig']->render('backend/pago/index.html.twig', $datos);
  }     

	

	public function verPagosAction($request, $datos = array()){


    function filtrarPorFecha($alumno,$anioCuota,$mesCuota) {

      $fechaIngreso = $alumno->getFechaIngreso();
      $anioIngreso = (int)($fechaIngreso->format('Y')); //obtengo el año
      $fechaEgreso = $alumno->getFechaEgreso();

      if ($fechaEgreso == null) {
        if ($anioIngreso < $anioCuota) {
          return true;
        } elseif ($anioIngreso == $anioCuota) {
          $mesIngreso = (int)($fechaIngreso->format('m')); //obtengo el mes
          //si ingresó en marzo debe pagar las cuotas de los meses posteriores
          if ($mesIngreso <= $mesCuota) {
            return true;
          }
        }
      } else {
          $anioEgreso = (int)($fechaEgreso->format('Y'));
          //si egresó en 2010 no debe pagar las cuotas de 2015
          if ($anioEgreso < $anioCuota) {
            return false;
          } elseif ($anioEgreso == $anioCuota) {
              $mesEgreso = (int)($fechaEgreso->format('m'));
              //si egresó en octubre debe pagar las cuotas anteriores
              if($mesEgreso >= $mesCuota){
                return true;
              }
            }
        }
      return false;
    } // fin filtrar


		if (isset($request['id'])) {
      $alumno = $GLOBALS['em']->getRepository('Anexa\Model\Entity\Alumno')->findOneById($request['id']);
      $pagos = $alumno->getPagos(); //pagos realizados por el alumno
      if (count($pagos) == 0) {
        $datos=array(
              'msj' => ' El alumno/a '.$alumno->getApellido().' no tiene pagos realizados',
              'success' => 0
          );
      }
      //todas las cuotas del sistema
        $todasCuotas = $GLOBALS['em']->getRepository('Anexa\Model\Entity\Cuota')->findBy(array(
          'borrado' => false),
        array(
          'anio' => 'DESC',
          'mes' => 'DESC'
          ));
        //$cuotasPagas = new ArrayCollection();
        $cuotasPagas = array();
        foreach ($pagos as $pago) {
          //$cuotasPagas->add($pago->getCuota()); //obtengo la cuota asociada con cada pago para obtener mes, año de la cuota
          $cuotasPagas[] = $pago->getCuota(); //obtengo la cuota asociada con cada pago para obtener mes, año de la cuota
        }
/*        $iterator = $cuotasPagas->getIterator();
        $iterator->uasort(function ($a, $b) {
            return (($a->getAnio() < $b->getAnio()) && ($a->getMes() < $b->getMes())) ? -1 : 1;
        });
        $cuotasPagas = new ArrayCollection(iterator_to_array($iterator));*/

      $cuotasNoPagas = array_diff($todasCuotas, $cuotasPagas); //diferencia entre todas las cuotas existentes
      //$noPagos = array_diff_key($todasCuotas, $cuotasPagas);      //y las ya pagas por el alumno
      $cuotasImpagas = array();
      foreach ($cuotasNoPagas as $cuota) {
        if (filtrarPorFecha($alumno, $cuota->getAnio(), $cuota->getMes())) {
          $cuotasImpagas[] = $cuota;
        }
      }      
    }

    if (count($cuotasImpagas) == 0) {
      $datos['msj'] = 'El alumno '.$alumno->getApellido().' '.$alumno->getNombre().' no tiene cuotas impagas';
      $datos['success'] = 0;
    }
    /*for ($i = 1; $i <= count($cuotasImpagas); $i++) {
        //uasort($cuotasImpagas, 'cmp');
    $collection = array();
    for ($i = 0; $i <= count($cuotasImpagas); $i++) {
        $cuo = $cuotasImpagas[$i];
        uasort($cuotasImpagas, array($cuotasImpagas[$i], 'cmp')); 
        
    } */
    $datos['cuotasPagas'] = $cuotasPagas;
    $datos['menu'] = 'pago';
    $datos['cuotasImpagas'] = $cuotasImpagas;
    $datos['alumno'] = $alumno;

    return $GLOBALS['twig']->render('backend/pago/listarPagos.html.twig', $datos); 
	}// fin ver pagos

	public function pagoSeleccionadoAction($request) {
    if (isset($request['alumnoId'])){
        $alumno = $GLOBALS['em']->getRepository('Anexa\Model\Entity\Alumno')->findOneById($request['alumnoId']);
        if (isset($request['coutas'])) {
          foreach ($request['coutas'] as $id) {
            $cuota = $GLOBALS['em']->getRepository('Anexa\Model\Entity\Cuota')->findOneById($id);
            $this->setAction($cuota, $alumno, false, new Pago);
          }
        }
        if (isset($request['becas'])) {
          foreach ($request['becas'] as $id) {
            $cuota = $GLOBALS['em']->getRepository('Anexa\Model\Entity\Cuota')->findOneById($id);
            $this->setAction($cuota, $alumno, true, new Pago);
          }
        }
        $datos=array(
          'msj' => ' Los pagos fueron efectuados correctamente',
          'success' => 1
        );
        return $this->verPagosAction(array('id'=>$alumno->getId()), $datos);
    }else{
        return $this->indexAction();
    }
  }

  public function setAction($cuota, $alumno, $beca, $pago) {  
    $pagoEfectuado=$GLOBALS['em']->getRepository('Anexa\Model\Entity\Pago')->findBy(array('alumno' => $alumno, 'cuota' => $cuota ));
    if (count($pagoEfectuado) < 1){
      try {
          $pago->setAlumno($alumno);
          $pago->setCuota($cuota);          
          $pago->setFecha(new \DateTime());
          $pago->setFechaAlta(new \DateTime());
          $pago->setFechaActualizacion(new \DateTime());
          $pago->setBecado($beca);
          $GLOBALS['em']->persist($pago);
          $GLOBALS['em']->flush();
          $cuota->addPago($pago);
          $alumno->addPago($pago);
          $GLOBALS['em']->persist($cuota);
          $GLOBALS['em']->persist($alumno);
          $GLOBALS['em']->flush();
          return true;
       } catch (Exception $e) {
          return false;
       } 
    }else{
      $datos=array(
          'msj' => ' La cuota a pagar ya estaba pagada',
          'success' => 0,
          'menu' => 'pago'
      );
      return $this->indexAction($datos);
    }
	} 

  public function deleteAction($request){
      if (isset($request['id'])) {
          $pago = $GLOBALS['em']->getRepository('Anexa\Model\Entity\Pago')->findOneById($request['id']);
          $alumno = $pago->getAlumno(); 
          $alumno->removePago($pago);
          $pago->toogle();
          $GLOBALS['em']->persist($alumno);
          $GLOBALS['em']->persist($pago);
          $GLOBALS['em']->flush();

          return $this->indexAction(array(
              'msj' => " el pago fue eliminado correctamente",
              'success' => 0
          ));
      }else{
          $datos=array(
              'msj' => ' no puede eliminar un pago sin pasar su identificacion!',
              'success' => 0
          );
          return $this->verPagoAction($datos);
      }
  }
}// fin controller