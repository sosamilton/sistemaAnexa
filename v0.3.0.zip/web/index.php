<?php
	header('Location: ./app.php');