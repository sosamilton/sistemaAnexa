<?php
namespace Anexa\Controller;
use Doctrine\ORM\EntityManager;
use Doctrine\ORM\EntityRepository;
use Anexa\Model\Entity\Alumno;
use Anexa\Model\Entity\Cuota;
use Anexa\Model\Entity\Usuario;
use Anexa\Model\Entity\Responsable;
use \Exception;


class listadoController {
	public function indexAction(){
		$coutasTodas = $GLOBALS['em']->getRepository('Anexa\Model\Entity\Cuota')->findBy(array('borrado'=>'false'));
		$anios=array();
		$meses=array();
		$matriculas=array();
		foreach ($coutasTodas as $couta) {
			if ($couta->getTipo() == "matricula") {
				$matriculas[$couta->getAnio()]=$couta->getAnio();
			}
			$anios[$couta->getAnio()]=$couta->getAnio();
			$meses[$couta->getMes()]=$couta->getMes();
		}
		$datos['menu'] = 'listado';	
		$datos['años_matricula'] = $matriculas;
		$datos['años'] = $anios;
		$datos['meses'] = $meses;	
		return $GLOBALS['twig']->render('backend/listado/index.html.twig', $datos);
	}

	public function matriculaPagaAction($request) {

		$matriculas = $GLOBALS['em']->getRepository('Anexa\Model\Entity\Cuota')->findBy(
					array('tipo'=>'matricula',
					'borrado'=>'false',
					'anio'=>$request['anio']
					)
				);
		if ($matriculas == null) {
			$msj = "No existe la matricula buscada";
			$datos['msj'] = $msj;

		} else {
			$todosPagos = array();
			foreach ($matriculas as $matricula) {
				$pagos=$matricula->getPagos();
				$todosPagos[]=$pagos;
				$alumnos=array();
				if (count($pagos) == 0) {
					$msj = 'No hay pagos de esta matricula';
					$datos ['msj'] = $msj;
				}else{
					foreach ($pagos as $key => $pago) {
						$alumnos[]=$pago->getAlumno();
					}
				}
			}
			if (isset($_SESSION['rol'])){
	            if ($_SESSION['rol'] == 'Consulta') {
	            	echo "string";
	                $usuario = $GLOBALS['em']->getRepository('Anexa\Model\Entity\Usuario')->findOneById($_SESSION['id']);
	                $responsable = $GLOBALS['em']->getRepository("Anexa\Model\Entity\Responsable")->findByUsuario($usuario);
	                $misAlumnos = $responsable->getAlumnosACargo();
	                //interseccion entre misAlumnos y alumnos que pagaron matricula
	                $alumnosAux = array_intersect_assoc($misAlumnos, $alumnos);
	                $alumnos = $alumnosAux;
				}
			}
			$datos['alumnos'] = $alumnos;
		}
		$datos['menu'] = 'listado';	
			
		return $GLOBALS['twig']->render('backend/listado/matriculados.html.twig', $datos);
	} // fin matricula



	public function cuotasPagasAction($request){
		$cuota = $GLOBALS['em']->getRepository('Anexa\Model\Entity\Cuota')->findOneBy(
					array('anio'=>$request['anio'],
						'mes' =>$request['mes'],
					'borrado'=>'false',
					)
				);
		if (!empty($cuota)) {
			$pagos=$cuota->getPagos();
			$alumnos=array();
			if (count($pagos) == 0) {
				$msj = 'No hay pagos de esta cuota';
				$datos ['msj'] = $msj;
			}else{
				foreach ($pagos as $key => $pago) {
						$alumnos[]=$pago->getAlumno();

					}
				}

			if (isset($_SESSION['rol'])){
	            if ($_SESSION['rol'] == 'Consulta') {
			        $usuario = $GLOBALS['em']->getRepository('Anexa\Model\Entity\Usuario')->findOneById($_SESSION['id']);
			        $responsable = $GLOBALS['em']->getRepository("Anexa\Model\Entity\Responsable")->findOneByUsuario($usuario);
			        $misAlumnos = (array)$responsable->getAlumnosACargo();
			        //interseccion entre misAlumnos y alumnos que pagaron la cuota
			        $alumnosAux = array_intersect_assoc($misAlumnos,$alumnos);
		        	$alumnos = $alumnosAux;
			        if (!count($alumnosAux) > 0) {      	
						$datos['msj'] = "Los Alumnos a su cargo no tienen ninguna cuota paga para ese mes/año";
						$datos['success'] =0;
			        }
				}
			}
			$datos['alumnos'] = $alumnos;
		} else {
			$datos['msj'] = "No existe la cuota buscada";
			$datos['success'] =0;
		}
			
		$datos['menu'] = 'listado';		
		return $GLOBALS['twig']->render('backend/listado/cuotasPagas.html.twig', $datos);

	} // fin cuotas pagas

	public function cuotasImpagasAction($request) {

		function filtrarPorFecha($alumno,$anioCuota,$mesCuota) {
		      $fechaIngreso = $alumno->getFechaIngreso();
		      $anioIngreso = (int)($fechaIngreso->format('Y')); //obtengo el año
		      $fechaEgreso = $alumno->getFechaEgreso();

		      if ($fechaEgreso == null) {
		        if ($anioIngreso < $anioCuota) {
		          return true;
		        } elseif ($anioIngreso == $anioCuota) {
		          $mesIngreso = (int)($fechaIngreso->format('m')); //obtengo el mes
		          //si ingresó en marzo debe pagar las cuotas de los meses posteriores
		          if ($mesIngreso <= $mesCuota) {
		            return true;
		          }
		        }
		      } else {
		          $anioEgreso = (int)($fechaEgreso->format('Y'));
		          //si egresó en 2010 no debe pagar las cuotas de 2015
		          if ($anioEgreso < $anioCuota) {
		            return false;
		          } elseif ($anioEgreso == $anioCuota) {
		              $mesEgreso = (int)($fechaEgreso->format('m'));
		              //si egresó en octubre debe pagar las cuotas anteriores
		              if($mesEgreso >= $mesCuota){
		                return true;
		              }
		            }
		        }
		      return false;
		    } // fin filtrar
		$cuota = $GLOBALS['em']->getRepository('Anexa\Model\Entity\Cuota')->findOneBy(
					array('anio'=>$request['anio'],
						'mes' =>$request['mes'],
					'borrado'=>'false',
					)
				);
		if (!empty($cuota)) {
			$pagos = $cuota->getPagos();			
			$alumnosPagaron=array();
			$todosAlumnos = $GLOBALS['em']->getRepository('Anexa\Model\Entity\Alumno')->findByBorrado('false');
			if (count($pagos) == 0) {
				$msj = 'No hay pagos de esta cuota';
				$datos ['msj'] = $msj;
			}else{
				foreach ($pagos as $key => $pago) {
						$alumnosPagaron[] = $pago->getAlumno();
					}
			}
			$alumnosNoPagaron = array_diff((array)$todosAlumnos, (array)$alumnosPagaron);

			if (count($alumnosNoPagaron) == 0) {
				$msj = 'Todos los alumnos pagaron la cuota indicada';
				$datos ['msj'] = $msj;
			} else {
				$alumnosDebenPagar = array();

				foreach ($alumnosNoPagaron as $alumno) {
	        		if (filtrarPorFecha($alumno, $cuota->getAnio(), $cuota->getMes())) {
	          			$alumnosDebenPagar[] = $alumno;
	        		}
	     		 } 

				if (isset($_SESSION['rol'])){
		            if ($_SESSION['rol'] == 'Consulta') {
				        $usuario = $GLOBALS['em']->getRepository('Anexa\Model\Entity\Usuario')->findOneById($_SESSION['id']);
				        $responsable = $GLOBALS['em']->getRepository("Anexa\Model\Entity\Responsable")->findByUsuario($usuario);
				        $misAlumnos = $responsable->getAlumnosACargo();
				        //interseccion entre misAlumnos y alumnos que deben pagaron la cuota
				        $alumnosAux = array_intersect_assoc($misAlumnos,$alumnosDebenPagar);
				        $alumnosDebenPagar = $alumnosAux;				        
					}
				}
				$datos['alumnos'] = $alumnosDebenPagar;
			}
			
		} else {
			$msj = 'No existe la cuota indicada';
			$datos ['msj'] = $msj;
		}
		$datos ['menu'] = 'listado';

		return $GLOBALS['twig']->render('backend/listado/cuotasImpagas.html.twig', $datos);


	} //fin cuotasPagas

} // fin controller