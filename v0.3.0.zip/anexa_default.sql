-- phpMyAdmin SQL Dump
-- version 4.2.12deb2
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 17-10-2015 a las 18:00:28
-- Versión del servidor: 5.6.25-0ubuntu0.15.04.1
-- Versión de PHP: 5.6.4-4ubuntu6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `anexa`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Alumno`
--

CREATE TABLE IF NOT EXISTS `Alumno` (
`id` int(11) NOT NULL,
  `borrado` tinyint(1) NOT NULL,
  `tipoDNI` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dni` int(11) NOT NULL,
  `apellido` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fechaNacimiento` datetime NOT NULL,
  `sexo` varchar(1) COLLATE utf8_unicode_ci NOT NULL,
  `direccion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `telefono` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fechaIngreso` datetime NOT NULL,
  `fechaEgreso` datetime DEFAULT NULL,
  `fechaAlta` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Configuracion`
--

CREATE TABLE IF NOT EXISTS `Configuracion` (
  `clave` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `valorNumerico` int(11) DEFAULT NULL,
  `valorTextual` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `Configuracion`
--

INSERT INTO `Configuracion` (`clave`, `valorNumerico`, `valorTextual`) VALUES
('descripcion', NULL, 'soy el sitio'),
('estado_sitio', 1, NULL),
('mail_contacto', NULL, 'info@anexa.unlp.edu.ar'),
('mensaje_deshabilitado', NULL, 'sitio en mantenimiento'),
('paginacion', 20, NULL),
('titulo', 0, 'Sistema de Anexa');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Cuota`
--

CREATE TABLE IF NOT EXISTS `Cuota` (
`id` int(11) NOT NULL,
  `borrado` tinyint(1) NOT NULL,
  `anio` int(11) NOT NULL,
  `mes` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `numero` int(11) NOT NULL,
  `monto` decimal(10,0) NOT NULL,
  `tipoCuota` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `comisionCobrador` decimal(10,0) NOT NULL,
  `fechaAlta` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Pago`
--

CREATE TABLE IF NOT EXISTS `Pago` (
`id` int(11) NOT NULL,
  `alumno_id` int(11) DEFAULT NULL,
  `cuota_id` int(11) DEFAULT NULL,
  `borrado` tinyint(1) NOT NULL,
  `fecha` datetime NOT NULL,
  `fechaAlta` datetime NOT NULL,
  `fechaActualizacion` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Responsable`
--

CREATE TABLE IF NOT EXISTS `Responsable` (
`id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `borrado` tinyint(1) NOT NULL,
  `tipoDNI` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dni` int(11) NOT NULL,
  `tipoResponsable` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `apellido` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fechaNacimiento` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sexo` varchar(1) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `telefono` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `direccion` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Responsables_Alumnos`
--

CREATE TABLE IF NOT EXISTS `Responsables_Alumnos` (
  `alumno_id` int(11) NOT NULL,
  `responsable_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Rol`
--

CREATE TABLE IF NOT EXISTS `Rol` (
`id` int(11) NOT NULL,
  `borrado` tinyint(1) NOT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `Rol`
--

INSERT INTO `Rol` (`id`, `borrado`, `nombre`) VALUES
(1, 0, 'Administracion'),
(2, 0, 'Gestion'),
(3, 0, 'Consulta');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Usuario`
--

CREATE TABLE IF NOT EXISTS `Usuario` (
`id` int(11) NOT NULL,
  `rol` int(11) NOT NULL,
  `borrado` tinyint(1) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `habilitado` tinyint(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `Usuario`
--

INSERT INTO `Usuario` (`id`, `rol`, `borrado`, `username`, `password`, `habilitado`) VALUES
(1, 1, 0, 'admin', '21232f297a57a5a743894a0e4a801fc3', 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `Alumno`
--
ALTER TABLE `Alumno`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `Configuracion`
--
ALTER TABLE `Configuracion`
 ADD PRIMARY KEY (`clave`), ADD UNIQUE KEY `UNIQ_DB52810464E8588B` (`clave`);

--
-- Indices de la tabla `Cuota`
--
ALTER TABLE `Cuota`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `Pago`
--
ALTER TABLE `Pago`
 ADD PRIMARY KEY (`id`), ADD KEY `IDX_54EDF000FC28E5EE` (`alumno_id`), ADD KEY `IDX_54EDF0006A7CF079` (`cuota_id`);

--
-- Indices de la tabla `Responsable`
--
ALTER TABLE `Responsable`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `UNIQ_D4CE82D0DB38439E` (`usuario_id`);

--
-- Indices de la tabla `Responsables_Alumnos`
--
ALTER TABLE `Responsables_Alumnos`
 ADD PRIMARY KEY (`alumno_id`,`responsable_id`), ADD KEY `IDX_BFA133ECFC28E5EE` (`alumno_id`), ADD KEY `IDX_BFA133EC53C59D72` (`responsable_id`);

--
-- Indices de la tabla `Rol`
--
ALTER TABLE `Rol`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `Usuario`
--
ALTER TABLE `Usuario`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `UNIQ_EDD889C1F85E0677` (`username`), ADD KEY `IDX_EDD889C1E553F37` (`rol`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `Alumno`
--
ALTER TABLE `Alumno`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `Cuota`
--
ALTER TABLE `Cuota`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `Pago`
--
ALTER TABLE `Pago`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `Responsable`
--
ALTER TABLE `Responsable`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `Rol`
--
ALTER TABLE `Rol`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `Usuario`
--
ALTER TABLE `Usuario`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `Pago`
--
ALTER TABLE `Pago`
ADD CONSTRAINT `FK_54EDF0006A7CF079` FOREIGN KEY (`cuota_id`) REFERENCES `Cuota` (`id`),
ADD CONSTRAINT `FK_54EDF000FC28E5EE` FOREIGN KEY (`alumno_id`) REFERENCES `Alumno` (`id`);

--
-- Filtros para la tabla `Responsable`
--
ALTER TABLE `Responsable`
ADD CONSTRAINT `FK_D4CE82D0DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuario` (`id`);

--
-- Filtros para la tabla `Responsables_Alumnos`
--
ALTER TABLE `Responsables_Alumnos`
ADD CONSTRAINT `FK_BFA133EC53C59D72` FOREIGN KEY (`responsable_id`) REFERENCES `Responsable` (`id`) ON DELETE CASCADE,
ADD CONSTRAINT `FK_BFA133ECFC28E5EE` FOREIGN KEY (`alumno_id`) REFERENCES `Alumno` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `Usuario`
--
ALTER TABLE `Usuario`
ADD CONSTRAINT `FK_EDD889C1E553F37` FOREIGN KEY (`rol`) REFERENCES `Rol` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
